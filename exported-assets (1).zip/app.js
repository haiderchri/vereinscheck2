// Vereins-Check Application JavaScript

// Application data structure
const assessmentData = {
  "categories": [
    {
      "id": "allgemeines",
      "name": "Allgemeines zum Verein",
      "weight": 0.05,
      "questions": [
        {
          "id": "allg_1",
          "text": "Ist der Verein ordnungsgemäß gegründet und im Vereinsregister eingetragen?"
        },
        {
          "id": "allg_2",
          "text": "Gibt es eine aktuelle Mitgliederliste und wird diese regelmäßig aktualisiert?"
        },
        {
          "id": "allg_3",
          "text": "Finden regelmäßige Mitgliederversammlungen statt?"
        },
        {
          "id": "allg_4",
          "text": "Sind die Ziele des Vereins klar definiert und allen Mitgliedern bekannt?"
        },
        {
          "id": "allg_5",
          "text": "Ist der Verein in der Gemeinde gut verankert und anerkannt?"
        }
      ]
    },
    {
      "id": "struktur",
      "name": "Vereinsstruktur",
      "weight": 0.15,
      "questions": [
        {
          "id": "str_1",
          "text": "Ist der Vorstand vollständig besetzt und arbeitet er effektiv zusammen?"
        },
        {
          "id": "str_2",
          "text": "Sind die Aufgaben und Verantwortlichkeiten im Vorstand klar verteilt?"
        },
        {
          "id": "str_3",
          "text": "Gibt es einen aktuellen Organisationsplan mit definierten Zuständigkeiten?"
        },
        {
          "id": "str_4",
          "text": "Werden Vorstandssitzungen regelmäßig abgehalten und protokolliert?"
        },
        {
          "id": "str_5",
          "text": "Ist die Nachfolgeplanung für Vorstandspositionen geregelt?"
        }
      ]
    },
    {
      "id": "verwaltung",
      "name": "Verwaltung",
      "weight": 0.15,
      "questions": [
        {
          "id": "ver_1",
          "text": "Werden alle rechtlichen Vorgaben für Vereine eingehalten und dokumentiert?"
        },
        {
          "id": "ver_2",
          "text": "Ist die Vereinssatzung aktuell und entspricht den gesetzlichen Anforderungen?"
        },
        {
          "id": "ver_3",
          "text": "Werden Beschlüsse ordnungsgemäß dokumentiert und archiviert?"
        },
        {
          "id": "ver_4",
          "text": "Gibt es ein funktionierendes System zur Mitgliederverwaltung?"
        },
        {
          "id": "ver_5",
          "text": "Werden Datenschutzbestimmungen eingehalten und umgesetzt?"
        }
      ]
    },
    {
      "id": "oeffentlichkeit",
      "name": "Öffentlichkeitsarbeit",
      "weight": 0.10,
      "questions": [
        {
          "id": "oef_1",
          "text": "Hat der Verein einen aktuellen Internetauftritt (Website, Social Media)?"
        },
        {
          "id": "oef_2",
          "text": "Werden regelmäßig Presseberichte über Vereinsaktivitäten veröffentlicht?"
        },
        {
          "id": "oef_3",
          "text": "Gibt es Informationsmaterial über den Verein und seine Aktivitäten?"
        },
        {
          "id": "oef_4",
          "text": "Wird die Bevölkerung aktiv über Projekte und Vorhaben informiert?"
        },
        {
          "id": "oef_5",
          "text": "Ist ein Verantwortlicher für Öffentlichkeitsarbeit benannt?"
        }
      ]
    },
    {
      "id": "organisation",
      "name": "Organisation und Sektionen",
      "weight": 0.10,
      "questions": [
        {
          "id": "org_1",
          "text": "Gibt es eine effektive Organisationsstruktur für Veranstaltungen und Projekte?"
        },
        {
          "id": "org_2",
          "text": "Werden Arbeitsgruppen oder Sektionen bei Bedarf gebildet und koordiniert?"
        },
        {
          "id": "org_3",
          "text": "Ist die Kommunikation zwischen Vorstand und Arbeitsgruppen/Sektionen gut?"
        },
        {
          "id": "org_4",
          "text": "Gibt es klare Verantwortlichkeiten bei der Durchführung von Projekten?"
        },
        {
          "id": "org_5",
          "text": "Werden erfolgreiche Organisationsmethoden dokumentiert und wiederverwendet?"
        }
      ]
    },
    {
      "id": "nachwuchs",
      "name": "Vereinsentwicklung - Nachwuchs",
      "weight": 0.10,
      "questions": [
        {
          "id": "nac_1",
          "text": "Gibt es spezielle Angebote für junge Mitglieder oder Interessenten?"
        },
        {
          "id": "nac_2",
          "text": "Werden junge Menschen aktiv in die Vereinsarbeit eingebunden?"
        },
        {
          "id": "nac_3",
          "text": "Gibt es eine Strategie zur Nachwuchsgewinnung und -förderung?"
        },
        {
          "id": "nac_4",
          "text": "Werden die Interessen und Bedürfnisse junger Menschen berücksichtigt?"
        },
        {
          "id": "nac_5",
          "text": "Ist die Altersstruktur im Verein ausgewogen?"
        }
      ]
    },
    {
      "id": "leitbild",
      "name": "Vereinsentwicklung - Leitbild",
      "weight": 0.10,
      "questions": [
        {
          "id": "lei_1",
          "text": "Hat der Verein ein schriftliches Leitbild oder Selbstverständnis?"
        },
        {
          "id": "lei_2",
          "text": "Wird das Leitbild regelmäßig überprüft und aktualisiert?"
        },
        {
          "id": "lei_3",
          "text": "Sind die Mitglieder mit dem Leitbild vertraut und identifizieren sich damit?"
        },
        {
          "id": "lei_4",
          "text": "Orientieren sich Entscheidungen und Aktivitäten am Leitbild?"
        },
        {
          "id": "lei_5",
          "text": "Werden regelmäßig Entwicklungsziele für den Verein definiert?"
        }
      ]
    },
    {
      "id": "kooperationen",
      "name": "Vereinsentwicklung - Kooperationen",
      "weight": 0.10,
      "questions": [
        {
          "id": "koo_1",
          "text": "Gibt es Kooperationen mit anderen Vereinen oder Organisationen?"
        },
        {
          "id": "koo_2",
          "text": "Wird mit der Gemeinde/Stadt aktiv zusammengearbeitet?"
        },
        {
          "id": "koo_3",
          "text": "Gibt es Kooperationen mit Bildungseinrichtungen oder Unternehmen?"
        },
        {
          "id": "koo_4",
          "text": "Werden Netzwerke aktiv gepflegt und ausgebaut?"
        },
        {
          "id": "koo_5",
          "text": "Werden gemeinsame Projekte mit Partnern durchgeführt?"
        }
      ]
    },
    {
      "id": "finanzen",
      "name": "Finanzen",
      "weight": 0.10,
      "questions": [
        {
          "id": "fin_1",
          "text": "Wird eine ordnungsgemäße Buchführung durchgeführt und dokumentiert?"
        },
        {
          "id": "fin_2",
          "text": "Gibt es einen jährlichen Finanzplan und wird dieser eingehalten?"
        },
        {
          "id": "fin_3",
          "text": "Werden Fördermöglichkeiten recherchiert und genutzt?"
        },
        {
          "id": "fin_4",
          "text": "Ist die finanzielle Situation des Vereins stabil?"
        },
        {
          "id": "fin_5",
          "text": "Werden finanzielle Risiken erkannt und minimiert?"
        }
      ]
    },
    {
      "id": "herausforderungen",
      "name": "Allgemeine Herausforderungen",
      "weight": 0.05,
      "questions": [
        {
          "id": "her_1",
          "text": "Werden aktuelle Herausforderungen und Probleme offen diskutiert?"
        },
        {
          "id": "her_2",
          "text": "Gibt es Strategien zum Umgang mit schwierigen Situationen?"
        },
        {
          "id": "her_3",
          "text": "Werden Konflikte konstruktiv gelöst?"
        },
        {
          "id": "her_4",
          "text": "Ist der Verein auf künftige Entwicklungen vorbereitet?"
        },
        {
          "id": "her_5",
          "text": "Werden externe Einflüsse und Trends beobachtet und berücksichtigt?"
        }
      ]
    }
  ]
};

// Global state
let currentState = {
  currentSection: 'welcome',
  currentCategoryIndex: 0,
  responses: {},
  currentDashboardCategory: 0
};

let scoresChart = null;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
  initializeNavigation();
  initializeAssessment();
  showSection('welcome');
});

// Navigation functions
function initializeNavigation() {
  const welcomeBtn = document.getElementById('welcomeBtn');
  const assessmentBtn = document.getElementById('assessmentBtn');
  const dashboardBtn = document.getElementById('dashboardBtn');
  const resetBtn = document.getElementById('resetBtn');
  const startAssessmentBtn = document.getElementById('startAssessmentBtn');

  welcomeBtn.addEventListener('click', () => showSection('welcome'));
  assessmentBtn.addEventListener('click', () => showSection('assessment'));
  dashboardBtn.addEventListener('click', () => showSection('dashboard'));
  resetBtn.addEventListener('click', resetAssessment);
  startAssessmentBtn.addEventListener('click', () => showSection('assessment'));
}

function showSection(sectionName) {
  // Hide all sections
  document.getElementById('welcomeSection').classList.add('hidden');
  document.getElementById('assessmentSection').classList.add('hidden');
  document.getElementById('dashboardSection').classList.add('hidden');

  // Update navigation buttons
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));

  // Show selected section
  switch(sectionName) {
    case 'welcome':
      document.getElementById('welcomeSection').classList.remove('hidden');
      document.getElementById('welcomeBtn').classList.add('active');
      break;
    case 'assessment':
      document.getElementById('assessmentSection').classList.remove('hidden');
      document.getElementById('assessmentBtn').classList.add('active');
      if (currentState.currentSection !== 'assessment') {
        initializeAssessmentView();
      }
      break;
    case 'dashboard':
      document.getElementById('dashboardSection').classList.remove('hidden');
      document.getElementById('dashboardBtn').classList.add('active');
      initializeDashboard();
      break;
  }

  currentState.currentSection = sectionName;
}

// Assessment functions
function initializeAssessment() {
  const prevBtn = document.getElementById('prevCategoryBtn');
  const nextBtn = document.getElementById('nextCategoryBtn');
  const showResultsBtn = document.getElementById('showResultsBtn');

  prevBtn.addEventListener('click', () => navigateCategory(-1));
  nextBtn.addEventListener('click', () => navigateCategory(1));
  showResultsBtn.addEventListener('click', () => showSection('dashboard'));
}

function initializeAssessmentView() {
  renderCategoryTabs();
  renderCurrentCategory();
  updateProgress();
  updateNavigationButtons();
}

function renderCategoryTabs() {
  const tabsContainer = document.getElementById('categoryTabs');
  tabsContainer.innerHTML = '';

  assessmentData.categories.forEach((category, index) => {
    const tab = document.createElement('button');
    tab.className = `category-tab ${index === currentState.currentCategoryIndex ? 'active' : ''}`;
    
    const isCompleted = isCategoryCompleted(category.id);
    if (isCompleted) {
      tab.classList.add('completed');
    }

    tab.innerHTML = `
      <span class="tab-name">${category.name}</span>
      <span class="tab-status">${isCompleted ? '✓' : (index + 1)}</span>
    `;

    tab.addEventListener('click', () => {
      currentState.currentCategoryIndex = index;
      renderCategoryTabs();
      renderCurrentCategory();
      updateProgress();
      updateNavigationButtons();
    });

    tabsContainer.appendChild(tab);
  });
}

function renderCurrentCategory() {
  const category = assessmentData.categories[currentState.currentCategoryIndex];
  
  document.getElementById('categoryTitle').textContent = category.name;
  document.getElementById('categoryWeight').textContent = `Gewichtung: ${Math.round(category.weight * 100)}%`;

  const container = document.getElementById('questionsContainer');
  container.innerHTML = '';

  category.questions.forEach((question, questionIndex) => {
    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-item';

    const currentValue = currentState.responses[question.id] || null;

    questionDiv.innerHTML = `
      <div class="question-text">${question.text}</div>
      <div class="rating-options">
        ${[1, 2, 3, 4].map(value => `
          <div class="rating-option ${currentValue === value ? 'selected' : ''}" data-question="${question.id}" data-value="${value}">
            <div class="rating-value">${value}</div>
            <div class="rating-label">${getRatingLabel(value)}</div>
          </div>
        `).join('')}
      </div>
    `;

    // Add event listeners for rating options
    const ratingOptions = questionDiv.querySelectorAll('.rating-option');
    ratingOptions.forEach(option => {
      option.addEventListener('click', () => {
        const questionId = option.dataset.question;
        const value = parseInt(option.dataset.value);
        
        // Store the response
        currentState.responses[questionId] = value;
        
        // Update visual selection for this question
        ratingOptions.forEach(opt => opt.classList.remove('selected'));
        option.classList.add('selected');
        
        // Update UI elements
        renderCategoryTabs();
        updateProgress();
        updateNavigationButtons();
        
        console.log('Response saved:', questionId, value, currentState.responses);
      });
    });

    container.appendChild(questionDiv);
  });
}

function getRatingLabel(value) {
  const labels = {
    1: 'Nicht vorhanden',
    2: 'Ansatzweise',
    3: 'Gut vorhanden',
    4: 'Sehr gut'
  };
  return labels[value];
}

function navigateCategory(direction) {
  const newIndex = currentState.currentCategoryIndex + direction;
  if (newIndex >= 0 && newIndex < assessmentData.categories.length) {
    currentState.currentCategoryIndex = newIndex;
    renderCategoryTabs();
    renderCurrentCategory();
    updateProgress();
    updateNavigationButtons();
  }
}

function updateProgress() {
  const totalQuestions = assessmentData.categories.reduce((sum, cat) => sum + cat.questions.length, 0);
  const answeredQuestions = Object.keys(currentState.responses).length;
  const progressPercentage = (answeredQuestions / totalQuestions) * 100;

  document.getElementById('progressText').textContent = 
    `Kategorie ${currentState.currentCategoryIndex + 1} von ${assessmentData.categories.length} - ${answeredQuestions}/${totalQuestions} Fragen beantwortet`;
  document.getElementById('progressFill').style.width = `${progressPercentage}%`;
}

function updateNavigationButtons() {
  const prevBtn = document.getElementById('prevCategoryBtn');
  const nextBtn = document.getElementById('nextCategoryBtn');
  const showResultsBtn = document.getElementById('showResultsBtn');

  prevBtn.disabled = currentState.currentCategoryIndex === 0;
  
  const isLastCategory = currentState.currentCategoryIndex === assessmentData.categories.length - 1;
  const allQuestionsAnswered = getTotalAnsweredQuestions() === getTotalQuestions();

  if (isLastCategory && allQuestionsAnswered) {
    nextBtn.classList.add('hidden');
    showResultsBtn.classList.remove('hidden');
  } else {
    nextBtn.classList.remove('hidden');
    showResultsBtn.classList.add('hidden');
    nextBtn.disabled = false;
  }
}

function isCategoryCompleted(categoryId) {
  const category = assessmentData.categories.find(cat => cat.id === categoryId);
  return category.questions.every(question => currentState.responses[question.id] !== undefined);
}

function getTotalQuestions() {
  return assessmentData.categories.reduce((sum, cat) => sum + cat.questions.length, 0);
}

function getTotalAnsweredQuestions() {
  return Object.keys(currentState.responses).length;
}

function resetAssessment() {
  if (confirm('Möchten Sie wirklich alle Bewertungen zurücksetzen?')) {
    currentState.responses = {};
    currentState.currentCategoryIndex = 0;
    currentState.currentDashboardCategory = 0;
    
    if (currentState.currentSection === 'assessment') {
      initializeAssessmentView();
    }
    
    if (scoresChart) {
      scoresChart.destroy();
      scoresChart = null;
    }
  }
}

// Dashboard functions
function initializeDashboard() {
  console.log('Initializing dashboard with responses:', currentState.responses);
  
  if (getTotalAnsweredQuestions() === 0) {
    // Show empty state if no responses
    showEmptyDashboard();
    return;
  }

  renderDashboardCategories();
  createDashboardChart();
  updateOverallScore();
  selectDashboardCategory(currentState.currentDashboardCategory);
}

function showEmptyDashboard() {
  document.getElementById('overallScoreValue').textContent = '-';
  document.getElementById('categoriesList').innerHTML = '<p style="padding: 16px; color: var(--color-text-secondary); text-align: center;">Noch keine Bewertungen vorhanden. Beginnen Sie mit der Bewertung, um Ergebnisse zu sehen.</p>';
  
  const chartContainer = document.getElementById('scoresChart').getContext('2d');
  if (scoresChart) {
    scoresChart.destroy();
  }
  
  scoresChart = new Chart(chartContainer, {
    type: 'bar',
    data: {
      labels: assessmentData.categories.map(cat => cat.name),
      datasets: [{
        label: 'Score',
        data: new Array(assessmentData.categories.length).fill(0),
        backgroundColor: '#e0e0e0',
        borderColor: '#e0e0e0',
        borderWidth: 1,
        borderRadius: 6,
      }]
    },
    options: getChartOptions()
  });
  
  // Show empty state for category details
  document.getElementById('detailCategoryTitle').textContent = 'Kategorie auswählen';
  document.getElementById('detailCategoryScore').textContent = '-';
  document.getElementById('detailCategoryDescription').textContent = 'Wählen Sie eine Kategorie aus der Liste, um Details zu sehen.';
  document.getElementById('detailQuestionsList').innerHTML = '';
  document.getElementById('detailRecommendations').textContent = 'Wählen Sie eine Kategorie aus, um Empfehlungen zu erhalten.';
}

function renderDashboardCategories() {
  const container = document.getElementById('categoriesList');
  container.innerHTML = '';

  assessmentData.categories.forEach((category, index) => {
    const score = calculateCategoryScore(category.id);
    const scoreClass = getScoreClass(score);
    
    const button = document.createElement('button');
    button.className = `category-button ${index === currentState.currentDashboardCategory ? 'active' : ''}`;
    button.onclick = () => selectDashboardCategory(index);
    
    button.innerHTML = `
      <span class="category-name">${category.name}</span>
      <span class="category-score-pill ${scoreClass}">${score !== null ? score.toFixed(1) : '-'}</span>
    `;
    
    container.appendChild(button);
  });
}

function createDashboardChart() {
  const ctx = document.getElementById('scoresChart').getContext('2d');
  
  if (scoresChart) {
    scoresChart.destroy();
  }

  const labels = assessmentData.categories.map(cat => cat.name);
  const scores = assessmentData.categories.map(cat => calculateCategoryScore(cat.id) || 0);
  const backgroundColors = scores.map(score => getScoreColor(score));
  
  console.log('Creating chart with scores:', scores);
  
  scoresChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Score',
        data: scores,
        backgroundColor: backgroundColors,
        borderColor: backgroundColors,
        borderWidth: 1,
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: getChartOptions()
  });
}

function getChartOptions() {
  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            return `Score: ${context.parsed.y.toFixed(1)} / 4.0`;
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        max: 4,
        ticks: {
          stepSize: 0.5,
          callback: function(value) {
            return value.toFixed(1);
          }
        },
        grid: {
          color: 'rgba(0, 0, 0, 0.1)'
        }
      },
      x: {
        ticks: {
          maxRotation: 45,
          minRotation: 45,
          font: {
            size: 11
          }
        },
        grid: {
          display: false
        }
      }
    },
    onClick: (event, elements) => {
      if (elements.length > 0) {
        const index = elements[0].index;
        selectDashboardCategory(index);
      }
    }
  };
}

function selectDashboardCategory(index) {
  currentState.currentDashboardCategory = index;
  const category = assessmentData.categories[index];
  
  // Update active category button
  document.querySelectorAll('.category-button').forEach((btn, i) => {
    btn.classList.toggle('active', i === index);
  });
  
  // Update category details
  updateDashboardCategoryDetails(category);
  
  // Update chart highlight
  updateChartHighlight(index);
}

function updateDashboardCategoryDetails(category) {
  const score = calculateCategoryScore(category.id);
  const scoreClass = getScoreClass(score);
  
  document.getElementById('detailCategoryTitle').textContent = category.name;
  document.getElementById('detailCategoryScore').textContent = score !== null ? score.toFixed(1) : '-';
  document.getElementById('detailCategoryScore').className = `category-score-badge ${scoreClass}`;
  
  document.getElementById('detailCategoryDescription').textContent = getCategoryDescription(category.id);
  
  renderDashboardQuestions(category);
  document.getElementById('detailRecommendations').textContent = getRecommendations(category.id, score);
}

function renderDashboardQuestions(category) {
  const container = document.getElementById('detailQuestionsList');
  container.innerHTML = '';
  
  category.questions.forEach(question => {
    const userScore = currentState.responses[question.id];
    
    const questionDiv = document.createElement('div');
    questionDiv.className = 'question-detail-item';
    
    questionDiv.innerHTML = `
      <span class="question-detail-text">${question.text}</span>
      <div class="question-score">
        <span class="score-number ${userScore ? `score-${userScore}` : ''}">${userScore || '-'}</span>
      </div>
    `;
    
    container.appendChild(questionDiv);
  });
}

function updateChartHighlight(selectedIndex) {
  if (!scoresChart) return;
  
  const scores = assessmentData.categories.map(cat => calculateCategoryScore(cat.id) || 0);
  const backgroundColors = scores.map((score, index) => {
    let baseColor = getScoreColor(score);
    
    // Highlight selected category
    if (index === selectedIndex) {
      return baseColor;
    } else {
      // Make non-selected categories slightly transparent
      return baseColor + '80';
    }
  });
  
  scoresChart.data.datasets[0].backgroundColor = backgroundColors;
  scoresChart.data.datasets[0].borderColor = backgroundColors;
  scoresChart.update('none');
}

function updateOverallScore() {
  const overallScore = calculateOverallScore();
  document.getElementById('overallScoreValue').textContent = 
    overallScore !== null ? overallScore.toFixed(1) : '-';
}

// Calculation functions
function calculateCategoryScore(categoryId) {
  const category = assessmentData.categories.find(cat => cat.id === categoryId);
  if (!category) {
    console.warn('Category not found:', categoryId);
    return null;
  }
  
  const responses = category.questions.map(q => currentState.responses[q.id]).filter(r => r !== undefined);
  
  if (responses.length === 0) return null;
  
  const score = responses.reduce((sum, score) => sum + score, 0) / responses.length;
  console.log(`Category ${categoryId} score:`, score, 'from responses:', responses);
  return score;
}

function calculateOverallScore() {
  let totalWeightedScore = 0;
  let totalWeight = 0;
  
  assessmentData.categories.forEach(category => {
    const categoryScore = calculateCategoryScore(category.id);
    if (categoryScore !== null) {
      totalWeightedScore += categoryScore * category.weight;
      totalWeight += category.weight;
    }
  });
  
  return totalWeight > 0 ? totalWeightedScore / totalWeight : null;
}

// Helper functions
function getScoreClass(score) {
  if (score === null) return 'neutral';
  if (score < 2.0) return 'critical';
  if (score < 3.0) return 'warning';
  return 'good';
}

function getScoreColor(score) {
  if (score < 2.0) return '#DC143C';
  if (score < 3.0) return '#FF8C00';
  return '#228B22';
}

function getCategoryDescription(categoryId) {
  const descriptions = {
    'allgemeines': 'Grundlegende Vereinsinformationen, Mitgliederstruktur und Hauptziele',
    'struktur': 'Organisatorischer Aufbau, Vorstandsbesetzung und Entscheidungsprozesse',
    'verwaltung': 'Mitgliederverwaltung, Dokumentation und administrative Abläufe',
    'oeffentlichkeit': 'Kommunikationskanäle, Außendarstellung und Medienarbeit',
    'organisation': 'Koordination verschiedener Vereinsbereiche und Arbeitsgruppen',
    'nachwuchs': 'Nachwuchsförderung und Einbindung junger Mitglieder',
    'leitbild': 'Entwicklung und Umsetzung des Vereinsleitbilds',
    'kooperationen': 'Partnerschaften und Zusammenarbeit mit anderen Organisationen',
    'finanzen': 'Finanzplanung, Kassenverwaltung und Fördergelder',
    'herausforderungen': 'Strategische Herausforderungen und Zukunftsplanung'
  };
  return descriptions[categoryId] || '';
}

function getRecommendations(categoryId, score) {
  if (score === null) {
    return 'Bewerten Sie zunächst alle Fragen in dieser Kategorie, um Empfehlungen zu erhalten.';
  }
  
  const recommendations = {
    'allgemeines': {
      critical: 'Grundlegende Vereinsstrukturen müssen dringend etabliert werden. Beginnen Sie mit der ordnungsgemäßen Registrierung und klaren Zieldefinition.',
      warning: 'Stärken Sie die Kommunikation der Vereinsziele und arbeiten Sie an einer präziseren Zielgruppendefinition.',
      good: 'Sehr gute Basis vorhanden. Halten Sie die Standards aufrecht und optimieren Sie kontinuierlich.'
    },
    'struktur': {
      critical: 'Die Vereinsstruktur benötigt eine komplette Neuorganisation. Besetzen Sie den Vorstand vollständig und definieren Sie klare Zuständigkeiten.',
      warning: 'Optimieren Sie die Rollendefinitionen und Entscheidungsprozesse für effizientere Vereinsarbeit.',
      good: 'Exzellente Vereinsstruktur. Nutzen Sie diese als Basis für weitere Entwicklungen.'
    },
    'verwaltung': {
      critical: 'Kritische Mängel in der Verwaltung. Implementieren Sie sofort ein ordnungsgemäßes Dokumentationssystem und stellen Sie die Rechtssicherheit her.',
      warning: 'Verbesserung der Dokumentenarchivierung und vollständige Umsetzung der DSGVO erforderlich.',
      good: 'Sehr gute Verwaltungsstruktur. Regelmäßige Überprüfung und Aktualisierung der Prozesse empfohlen.'
    },
    'oeffentlichkeit': {
      critical: 'Dringender Handlungsbedarf: Aufbau einer digitalen Präsenz und Einführung regelmäßiger Kommunikationsformate ist unerlässlich.',
      warning: 'Erweitern Sie Ihre Kommunikationskanäle und entwickeln Sie eine kohärente Öffentlichkeitsstrategie.',
      good: 'Starke Öffentlichkeitsarbeit. Nutzen Sie neue digitale Kanäle zur weiteren Optimierung.'
    },
    'organisation': {
      critical: 'Die interne Organisation muss grundlegend neu strukturiert werden. Etablieren Sie klare Arbeitsgruppen und Kommunikationswege.',
      warning: 'Verbesserung der internen Koordination und Kommunikation zwischen den Arbeitsbereichen notwendig.',
      good: 'Gut organisierte Vereinsstruktur. Dokumentieren Sie bewährte Praktiken für zukünftige Projekte.'
    },
    'nachwuchs': {
      critical: 'KRITISCHER BEREICH: Entwicklung einer umfassenden Nachwuchsstrategie mit gezielten Angeboten und Beteiligungsmöglichkeiten ist dringend erforderlich.',
      warning: 'Entwickeln Sie konkrete Programme zur Nachwuchsförderung und schaffen Sie attraktive Angebote für junge Menschen.',
      good: 'Sehr gute Nachwuchsarbeit. Bauen Sie Ihre Programme weiter aus und dokumentieren Sie Erfolgsmodelle.'
    },
    'leitbild': {
      critical: 'Ein Vereinsleitbild muss dringend entwickelt werden. Starten Sie einen partizipativen Prozess zur Leitbildentwicklung.',
      warning: 'Intensivieren Sie die regelmäßige Überprüfung und praktische Anwendung des Leitbilds.',
      good: 'Starkes Leitbild vorhanden. Nutzen Sie es als Kompass für strategische Entscheidungen.'
    },
    'kooperationen': {
      critical: 'Aufbau von Kooperationen ist essentiell für die Vereinsentwicklung. Beginnen Sie mit lokalen Partnerschaften.',
      warning: 'Ausbau der überregionalen Vernetzung und Entwicklung von Unternehmenspartnerschaften zur Stärkung der Kooperationsbasis.',
      good: 'Exzellente Vernetzung. Nutzen Sie Ihre Kooperationen für innovative Projekte.'
    },
    'finanzen': {
      critical: 'Die Finanzstruktur muss sofort professionalisiert werden. Implementieren Sie eine ordnungsgemäße Buchhaltung.',
      warning: 'Entwicklung einer langfristigen Finanzplanung zur strategischen Absicherung empfohlen.',
      good: 'Solide Finanzgrundlage. Diversifizieren Sie Ihre Einnahmequellen für mehr Stabilität.'
    },
    'herausforderungen': {
      critical: 'Strategieentwicklung ist dringend erforderlich. Implementieren Sie ein systematisches Risikomanagement.',
      warning: 'Entwicklung einer systematischen Strategieplanung und Einführung eines Risikomanagements zur Zukunftssicherung des Vereins.',
      good: 'Sehr gute strategische Ausrichtung. Bleiben Sie proaktiv bei der Trendbeobachtung.'
    }
  };
  
  const categoryRecs = recommendations[categoryId];
  if (!categoryRecs) return 'Keine spezifischen Empfehlungen verfügbar.';
  
  if (score < 2.0) return categoryRecs.critical;
  if (score < 3.0) return categoryRecs.warning;
  return categoryRecs.good;
}